﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CadastroSimulado
{
    /// <summary>
    /// Simulando um Banco de dados. Se fosse um entity framework você teria um context.Produto pra add e salvar
    /// </summary>
    public partial class DataBaseProduto
    {
        public DataBaseProduto()
        {
            BaseFisica = new ArrayList(); 
        }

        public static ArrayList BaseFisica { get; set; } //simulando sua base de dados no disco


        //Seu CRUD

        /// <summary>
        /// Incluir novo produto
        /// </summary>
        /// <param name="model"></param>
        public  void Incluir(Produto model)
        {
            if (!ValidaSeProdutoExiste(model.Id))
            {
                //Motivo para criar um novo objeto produto no momento de incluir é para simular uma base de dados física
                //Como a classe é passada por referência, se eu adicionar diretamente, a simulação não vai ficar boa na hora de alterar, deletar, etc.
                //Pois assim ocorre em uma situação real, a instância do objeto (model Produto) a ser incluido é diferente da instância vinda do banco
                BaseFisica.Add(new Produto() { Id = model.Id, Nome = model.Nome, Modelo = model.Modelo, Preco = model.Preco, Tamanho = model.Tamanho });
            }
            else
                throw new Exception(String.Format("Produto já cadastrado. Id: {0}; Nome: {1}", model.Id, model.Nome ));
        }

        /// <summary>
        /// Exclui um produto da base de dados
        /// </summary>
        /// <param name="model"></param>
        public  void Deletar(Produto model)
        {
            if (BaseFisica.Count > 0 && ValidaSeProdutoExiste(model.Id))
            {                
                BaseFisica.Remove(model);
            }
            else
                throw new Exception(String.Format("Produto não encontrado."));

        }

        /// <summary>
        /// Salva uma alteração no produto
        /// </summary>
        /// <param name="model"></param>
        public void Update(Produto model)
        {
            if (BaseFisica.Count > 0)
            {
                BaseFisica.Sort(new ComparaProdutoId());

                var result = BaseFisica.BinarySearch(model, new ComparaProdutoId()); //Searches a one-dimensional sorted Array for a value, using a binary search algorithm.

                if(result > 0)
                {
                    BaseFisica[result] = model;
                }
                else
                    throw new Exception(String.Format("Produto não encontrado."));
            }
            else
                throw new Exception(String.Format("Base de dados vazia."));

        }


        /// <summary>
        /// Verifica se o produto já existe
        /// </summary>
        /// <param name="id"></param>
        /// <returns>True - existe; False = Não existe</returns>
        private static bool ValidaSeProdutoExiste(int id)
        {
            //Sem uso de frameworks ou bibliotecas precisamos usar uma busca eficiente (a mais comumente ensinada na faculdade, que é a binaria)
            if (BaseFisica.Count > 0)
            {
                if (BaseFisica.Count > 1)
                {
                    BaseFisica.Sort(new ComparaProdutoId());

                    var result = BaseFisica.BinarySearch((new Produto(){Id = id}), new ComparaProdutoId()); //Searches a one-dimensional sorted Array for a value, using a binary search algorithm.

                    return result > 0;
                }
                else
                    return ((Produto)BaseFisica[0]).Id == id;
            }
            else
                return false;
        }



        /// <summary>
        /// Retorna um produto pelo Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public  Produto Find(int id)
        {
            BaseFisica.Sort(new ComparaProdutoId());

            var result = BaseFisica.BinarySearch((new Produto() { Id = id }), new ComparaProdutoId()); //Searches a one-dimensional sorted Array for a value, using a binary search algorithm.

            if (result > 0)
            {

                return (Produto)BaseFisica[result];
            }
            else
                return null;

        }



        /// <summary>
        /// Proximo id (geralmente controlado pelo banco usando um identity insert)
        /// </summary>
        /// <returns></returns>
        public int GetNextId()
        {
            if (BaseFisica.Count > 0)
            {
                if (BaseFisica.Count > 1)
                {
                    BaseFisica.Sort(new ComparaProdutoId());


                    return ((Produto)BaseFisica[BaseFisica.Count - 1]).Id++;
                }
                else
                    return ((Produto)BaseFisica[0]).Id++;
            }
            else
                return 1;
        }

        public int Count 
        {
            get
            {
                return BaseFisica.Count;
            }
        
        } //Exemplo de propriedada de somente leitura

        public IEnumerable<Produto> Listar()
        {
            return BaseFisica.Cast<Produto>();
        }
    }

    /// <summary>
    /// Realizar a ordenação dos produtos para poder executar a pesquisa binaria 
    /// Como se fosse o indice do id no banco de dados
    /// </summary>
    public  class ComparaProdutoId : IComparer
    {
        public int Compare(object x, object y)
        {
            return ((Produto)x).Id - ((Produto)y).Id;
        }


    }
}
