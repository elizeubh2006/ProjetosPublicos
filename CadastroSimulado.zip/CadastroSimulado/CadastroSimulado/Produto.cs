﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CadastroSimulado
{
    public partial class Produto
    {
        public int Id { get; set; } //Seu cadastro precisa de um id - Este não pode se repetir
        public string Nome { get; set; }
        public string Modelo { get; set; }
        public string Tamanho { get; set; }
        public decimal Preco { get; set; }

    }
}
