﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace CadastroSimulado
{

    /// <summary>
    /// Objetivo: Simular uma base de dados CRUD usando um ArrayList com menu no console
    /// Autor: Elizeu de Souza Ferreira
    /// Data: 4 de Julho de 2019
    /// Email: elizeubh2006@gmail.com
    /// </summary>
    class Program
    {
        private static DataBaseProduto context = new DataBaseProduto();
        static void Main(string[] args)
        {

            //Esta é a maneira mais usual (para quem esta aprendendo claro)
            int userInput = 0;
            do
            {
                userInput = DisplayMenu();
                Console.Clear(); //Nesta posição pra não apagar o resulto (mensagens)

                switch (userInput)
                {
                    case 1: //Novo
                        Produto model = new Produto();
                        model.Id = context.GetNextId();

                        Console.Write("Nome: ");
                        model.Nome = Console.ReadLine();

                        if(String.IsNullOrWhiteSpace(model.Nome))
                        {
                            Console.Clear();
                            Console.WriteLine("Ação cancelada.");
                        }

                        Console.Write("Modelo: ");
                        model.Modelo = Console.ReadLine();
                        Console.Write("Tamanho: ");
                        model.Tamanho = Console.ReadLine();

                        var prc = string.Empty;
                        decimal valor;
                        do
                        {
                            Console.Write("Preco: ");
                            prc = Console.ReadLine();

                        } while (String.IsNullOrWhiteSpace(prc) || !Decimal.TryParse(prc, out valor));

                        model.Preco = valor;

                        try
                        {
                            context.Incluir(model);
                            Console.Clear();
                            Console.WriteLine("");
                            Console.WriteLine("****************************************************************");
                            Console.WriteLine("");

                            Console.WriteLine(String.Format("Produto {0} Cadastrado com sucesso!", model.Nome));
             
                            Console.WriteLine("");
                            Console.WriteLine("****************************************************************");
                            Console.WriteLine("");
                        }
                        catch(Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }





                        break;
                    case 2: //Alterar

                        Produto modelAlterar = null; 
                        var continua = true;
                        do
                        {                          
                           var strId = string.Empty;
                            int intId;
                            do
                            {
                                Console.Write("Código do Produto (Id): ");
                                strId = Console.ReadLine();
                                if (String.IsNullOrWhiteSpace(strId))
                                {
                                    intId = -1;
                                    break;
                                }

                            } while ( !Int32.TryParse(strId, out intId));


                            if (intId < 0)
                            {
                                Console.Clear();
                                Console.WriteLine("Ação cancelada.");
                                break;
                            }

                            modelAlterar = context.Find(intId);


                            if (modelAlterar != null)
                            {
                                continua = false;
                            }
                            else
                                Console.WriteLine("Produto não encontrado.");

                        } while (continua);


                        Console.Write(String.Format("Nome: {0}", modelAlterar.Nome));
                        var newNome = Console.ReadLine();

                        if (!String.IsNullOrWhiteSpace(newNome))
                            modelAlterar.Nome = newNome;

                        Console.Write(String.Format("Modelo:  {0}", modelAlterar.Modelo));
                       var newModelo = Console.ReadLine();

                       if (!String.IsNullOrWhiteSpace(newModelo))
                           modelAlterar.Modelo = newModelo;

                        Console.Write(String.Format("Tamanho:  {0}", modelAlterar.Tamanho));
                        var newTamanho = Console.ReadLine();

                        if (!String.IsNullOrWhiteSpace(newTamanho))
                            modelAlterar.Tamanho = newTamanho;

                        var prcAlt = string.Empty;
                        decimal valorAlt;
                        do
                        {
                            Console.Write(String.Format("Preco:  {0}", modelAlterar.Preco));
                            prc = Console.ReadLine();

                        } while (String.IsNullOrWhiteSpace(prc) || !Decimal.TryParse(prcAlt, out valorAlt));

                        modelAlterar.Preco = valorAlt;

                        Console.Clear();
                        Console.WriteLine("");
                        Console.WriteLine("****************************************************************");
                        Console.WriteLine("");

                        Console.WriteLine(String.Format("Produto {0} Alterado com sucesso!", modelAlterar.Nome));
 
                        Console.WriteLine("");
                        Console.WriteLine("****************************************************************");
                        Console.WriteLine("");


                        break;
                    case 3: //Excluir
                        Produto modelExcluir = null; 
                        var strIdtoDelete = string.Empty;
                        continua = true;
                        do
                        {
                            strIdtoDelete = string.Empty;
                            int intId;
                            do
                            {
                                Console.Write("Código do Produto (Id): ");
                                strIdtoDelete = Console.ReadLine();
                                if (String.IsNullOrWhiteSpace(strIdtoDelete))
                                {
                                    intId = -1;
                                    break;
                                }

                            } while (!Int32.TryParse(strIdtoDelete, out intId));


                            if (intId < 0)
                            {
                                Console.Clear();
                                Console.WriteLine("Ação cancelada.");
                                break;
                            }

                            modelExcluir = context.Find(intId);


                            if (modelExcluir != null)
                            {
                                continua = false;
                            }
                            else
                                Console.WriteLine("Produto não encontrado.");

                        } while (continua);

                        context.Deletar(modelExcluir);

                        Console.Clear();
                        Console.WriteLine("");
                        Console.WriteLine("****************************************************************");
                        Console.WriteLine("");

                        Console.WriteLine(String.Format("Produto de Código {0} Excluido com sucesso!", strIdtoDelete));

                        Console.WriteLine("");
                        Console.WriteLine("****************************************************************");
                        Console.WriteLine("");

                        break;
                    case 4:  //Procurar
                        Produto modelExibir = null; 
                        continua = true;
                        do
                        {                          
                           var strId = string.Empty;
                            int intId;
                            do
                            {
                                Console.Write("Código do Produto (Deixe em vazio para sair): ");
                                strId = Console.ReadLine();
                                if (String.IsNullOrWhiteSpace(strId))
                                {
                                    intId = -1;
                                    break;
                                }

                            } while ( !Int32.TryParse(strId, out intId));


                            if (intId < 0)
                            {
                                Console.Clear();
                                Console.WriteLine("Ação cancelada.");
                                continua = false;
                            }

                            modelExibir = context.Find(intId);

                            Console.Clear();
                            if (modelExibir != null)
                            {
                                Console.WriteLine("");
                                Console.WriteLine("****************************************************************");
                                Console.WriteLine("");
                                Console.WriteLine(String.Format("Código (Id): {0}", modelExibir.Id));
                                Console.WriteLine(String.Format("Nome: {0}", modelExibir.Nome));
                                Console.WriteLine(String.Format("Modelo:  {0}", modelExibir.Modelo));
                                Console.WriteLine(String.Format("Tamanho:  {0}", modelExibir.Tamanho));
                                Console.WriteLine(String.Format("Preco:  {0}", modelExibir.Preco));
                                Console.WriteLine("");
                                Console.WriteLine("****************************************************************");
                                Console.WriteLine("");
                            }
                            else
                                Console.WriteLine("Produto não encontrado.");

                        } while (continua);





                        Console.Clear();

                        break;
                    case 5: //Listar
                        if (context.Count > 0)
                        {
                            Console.Clear();
                            Console.WriteLine("");
                            Console.WriteLine("****************************************************************");
                            Console.WriteLine("");
                            Console.WriteLine("Código  | Nome | Modelo | Tamanho | Preço (R$)");
                            var todosProdutos = context.Listar();
                            foreach(var item in todosProdutos)
                            {


                                Console.WriteLine(String.Format("{0}  | {1} | {2} | {3} | {4}", item.Id, item.Nome, item.Modelo, item.Tamanho, item.Preco));

                            }
                            Console.WriteLine("");
                            Console.WriteLine("****************************************************************");
                            Console.WriteLine("");
                        }
                        else
                            Console.WriteLine("Não há produtos cadastrados");

                        break;
                    default:
                        break;
                }

            } while (userInput != 6);
        }




        static public int DisplayMenu()
        {
            Console.WriteLine("Cadastro de Produtos");
            Console.WriteLine();
            Console.WriteLine("1. Novo Produto.");
            Console.WriteLine("2. Alterar um produto.");
            Console.WriteLine("3. Excluir um produto.");
            Console.WriteLine("4. Encontrar um produto.");
            Console.WriteLine("5. Listar os produtos.");
            Console.WriteLine("6. Exit");
            var result = Console.ReadLine();
            int Choice;

            if (Int32.TryParse(result, out Choice))
                return Convert.ToInt32(Choice);
            else
                return -1;

        }

        /// <summary>
        /// Teste das funções do seu CRUD
        /// </summary>
        private static void TesteMethod()
        {
            for (var i = 0; i < 10; i++)
            {
                var newProduto = new Produto();

                newProduto.Id = i + 1;

                context.Incluir(newProduto);


            }

            context.Deletar(context.Find(3));


            //Alteracao quando buscando o model diretamente do contexto.
            var proAlterar = context.Find(5);

            proAlterar.Nome = "Camisa Polo";


            //Alteração quando o model vem por uma outra forma, como um formulario html por exemplo
            var proAlterar2 = new Produto() { Id = 6, Nome = "Calça Jeans", Modelo = "Modelo Exemplo 1", Tamanho = "Extra GG", Preco = (decimal)1.99 };

            context.Update(proAlterar2);
        }
    }
}
